# Podjetje SQMalSys

tim project 1 :  sql + java + UI

vsem timom skupen repozitorij; ker je vse organizirano na demokratični osnovi, naj bo tako organiziran tudi vaš način dela s tem repozitorijem: 

ideje za razločevanje : veje, podgrupe/te morajo biti vidne vsem/ - pobude razrešuje upravljalec sam ali s prenosom
nadzora

Kakorkoli, ob zaključku so vsi oddani predlogi v tem repozitoriju, prav tako pa celoten doprinos vsakega posamznika.

Opis in nadaljna navodila/priporočila so v WIki tečaja predmeta RSO04.

a
-
swiizzzzzci
-
uporabili bomo mapo + branch z našim imenom
